<!DOCTYPE html>
<html lang="es">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <head>
  <!-- base_url() = http://localhost/ventas_ci/-->

  <!-- Bootstrap 3.3.7 -->
    <link href="<?php echo base_url();?>assets/template/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url();?>assets/template/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo base_url();?>assets/template/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="<?php echo base_url();?>assets/template/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    


   <!-- Bootstrap -->
   <link  href="<?php echo base_url();?>assets/template/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link  href="<?php echo base_url();?>assets/template/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link  href="<?php echo base_url();?>assets/template/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link  href="<?php echo base_url();?>assets/template/iCheck/skins/flat/green.css" rel="stylesheet">
	
    <!-- bootstrap-progressbar -->
    <link  href="<?php echo base_url();?>assets/template/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link  href="<?php echo base_url();?>assets/template/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link  href="<?php echo base_url();?>assets/template/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo base_url();?>assets/build/css/custom.css" rel="stylesheet">

    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/template/jquery/dist/jquery.min.js"></script>
     <!-- Datatables -->
    
     <link href="<?php echo base_url();?>assets/template/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/template/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/template/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/template/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/template/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet"> <!-- PNotify -->
    <link href="<?php echo base_url();?>assets/template/pnotify/dist/pnotify.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/template/pnotify/dist/pnotify.buttons.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/template/pnotify/dist/pnotify.nonblock.css" rel="stylesheet">
      
      

</head>
